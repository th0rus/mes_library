﻿namespace HRRBases
{
    interface IApplicationParameter : IParameter
    {
        //public properties
        string ApplicationName { get; }

        //public method
        void SetApplicationName(string ApplicationName);
    }
}