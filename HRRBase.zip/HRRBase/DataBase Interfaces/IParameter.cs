﻿using System;

namespace HRRBases
{
    interface IParameter : IComparable
    {

    }
}