﻿namespace HRRBases
{
    interface ISQLParameter
    {
        //public properties

    }
}