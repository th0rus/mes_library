﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    delegate void StartDatabaseAccessHandler();
    delegate void EndDatabaseAccessHandler();
    delegate void InfoMessageHandler();
    delegate void McKeyChangeHandler();


    interface IDatabase : IDisposable
    {
        //Events
        event StartDatabaseAccessHandler StartDatabaseAccess;
        event EndDatabaseAccessHandler EndDatabaseAccess;
        event InfoMessageHandler InfoMessage;
        event McKeyChangeHandler McKeyChange;

        //readonly properties for basic database elements
        string DBSource { get; }
        string DBUser { get; }
        string DBPassword { get; }
        Boolean IsOpen { get; }
        int CommandTimeOut { get;  }
        String CurrentSession { get;  }
        string CurrentWorkCenter { get; }
        Boolean ConnectionPooling { get;  }
        Boolean IsTransactionActive { get; }
        
        //complex property classes that expose another level of functionality
        IEmail Email { get; }
        IUser CurrentUser { get; }
        IParameters Parameters { get; }
        IMachine Machine { get; }
        IApplication Application { get; }

        //connection methods
        Boolean Connect();
        Boolean Disconnect();

        //transaction methods
        bool BeginTransaction();
        void CommitTransaction();
        void RollBackTransaction();

        //a test to see if a string is unsafe SQL
        bool UnSafeSQLString(string SQLStatement);

        DataTable SQLParamToDataTable(ISQLParameter inputParam);

        //query methods
        DbDataReader Query(string CommandText);
        DbDataReader Query(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);
        DataSet QueryReturnDataSet(string CommandText);
        DataSet QueryReturnDataSet(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);
        DataTable QueryReturnDataTable(string CommandText);
        DataTable QueryReturnDataTable(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);
        DataRow QueryReturnDataRow(string CommandText);
        DataRow QueryReturnDataRow(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);

        //unsafequery methods we may want to remove this
        DbDataReader unSafeQuery(string CommandText);
        DbDataReader unSafeQuery(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);

        //sqlblock methods
        void SQLBlock(string CommandText);
        void SQLBlock(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);

        //stored procedure
        void StoredProcedure(string CommandText, ISQLParamDictionary<string, ISQLParameter> Parameters);


        Boolean UserExistsInMFGDB(string UserName);
        double GetUserID(string UserName);
        string GetUserLogon(double UserID);
        string GetUserSession();
        string GetUserFirstAndLastName(string UserName);
        IUser GetUser(string UserName);
        IUser GetUserByUserID(double UserID);
        IUser getUserByPersonID(double HRRPersonID);


        //Factory methods
        IApplicationParameter ApplicationParameterFactory(string Application, string System, string Parameter, object NewValue);
        IMachineParameter MachineParameterFactory(string MCKEY, string System, string Parameter, object NewValue);
        ISQLParameter SQLParameterFactory();
    }
}
