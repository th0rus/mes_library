﻿namespace HRRBases
{
    interface ISQLParamDictionary<T1, T2>
    {
        ISQLParamDictionary<string, ISQLParameter> SQLParamDictionaryFactory();
    }
}