﻿using HRRBases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    interface IParameters
    {

        IMachine Machine { get; }
        IApplication Application { get; }
        Dictionary<string, Dictionary<string, IApplicationParameter>> ApplicationParameters { get; }
        Dictionary<string, Dictionary<string, IMachineParameter>> MachineParameters { get; }

        List<string> GetMachineSystemNames();
        List<string> GetApplicationSystemNames();

        void RefreshApplicationParameters();
        void RefreshMachineParameters();
        void RefreshParameters();

        void SetMachineParameter(string System, string Parameter, object NewValue);
        void SetMachineParameter(string MCKEY, string System, string Parameter, object NewValue);
        void SetMachineParameter(IMachineParameter NewParameter);

        void SetApplicationParameter(string System, string Parameter, object NewValue);
        void SetApplicationParameter(string Application, string System, string Parameter, object NewValue);
        void SetApplicationParameter(IApplicationParameter NewParameter);

    }
}
