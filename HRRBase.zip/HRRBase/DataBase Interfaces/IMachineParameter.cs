﻿using System;

namespace HRRBases
{
    interface IMachineParameter : IParameter
    {
        //public properties
        string MachineName { get; }

        //public methods
        void SetMachineName(string MachineName);
    }
}