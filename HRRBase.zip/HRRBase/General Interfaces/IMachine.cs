﻿using System;

namespace HRRBases
{
    interface IMachine : IComparable
    {
        //readonly properties
        string mckey { get; }
        string system { get; }

        //properties that we might not do
        string IP { get; }

        //a method to repopulate the properties
        void refresh();
    }
}