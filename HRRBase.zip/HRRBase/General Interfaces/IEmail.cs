﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    interface IEmail
    {
        void SendMail(string Receiver, string Subject, string Message, string Sender = "");
        void SendMail(string Receiver, string Subject, string Message, string Sender, string PathToAttachedFile);
    }
}
