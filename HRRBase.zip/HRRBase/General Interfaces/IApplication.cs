﻿using System;

namespace HRRBases
{
    interface IApplication : IComparable
    {
        string ApplicationName { get; }
        string VersionNumber { get; }
        DateTime VersionDate { get; }
        Boolean UncheckedModifications { get; }

    }
}