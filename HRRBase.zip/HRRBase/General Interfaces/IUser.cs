﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    interface IUser : IComparable
    {
        //Properties
        string UserName { get; }
        System.Security.SecureString Password { get; }
        string CostCenter { get; }
        string Barcode { get; }
        string UserID { get; }
        string DomainName { get; }
        string HRRPersonID { get; }
        string FirstName { get; }
        string LastName { get; }
        string FullName { get; }


        //Methods
        Boolean HasPermission(string PermissionType);
        List<string> GetPermissions();
        List<string> GetRoles();
    }
}
