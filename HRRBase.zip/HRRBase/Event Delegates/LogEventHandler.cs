﻿
namespace HRRBases
{
    //this may not even be needed since log events won't need to be handled by other libraries
    delegate void LogEventHandler();
}
