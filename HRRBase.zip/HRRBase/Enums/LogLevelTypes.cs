﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    enum LogLevelTypes
    {
        Fatal ,
        Error ,
        Warn,
        Info,
        Debug,
        Trace        
    }
}
