﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    enum WeightTypes
    {
        Ounce,
        Pound,
        Ton,
        Gram,
        Kilogram,
        MetricTon
    }
}
