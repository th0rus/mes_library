﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    enum LengthTypes
    {
        Inch,
        Foot,
        Yard,
        Mile,
        Millimeter,
        Centimeter,
        Meter,
        Kilometer
    }
}
