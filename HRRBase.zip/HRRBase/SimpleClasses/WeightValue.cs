﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    
    class WeightValue : INotifyPropertyChanged
    {
        private double _value;
        private WeightTypes _weightType;

        public event PropertyChangedEventHandler PropertyChanged;

        public WeightValue(Double Value, WeightTypes WeightType)
        {
            _value = Value;
            _weightType = WeightType;
        }

        public void SetWeight(Double Value, WeightTypes WeightType)
        {
            _value = Value;
            _weightType = WeightType;

            OnPropertyChanged("AsOunces");
            OnPropertyChanged("AsPounds");
            OnPropertyChanged("AsTons");
            OnPropertyChanged("AsKilograms");
            OnPropertyChanged("AsGrams");
            OnPropertyChanged("AsMetricTon");
        }

        public double AsOunces
        {
            get
            {
                switch (_weightType)
                {
                    case WeightTypes.Ounce:
                        return _value;
                    case WeightTypes.Pound:
                        return _value * WeightFactors.PoundToOunceFactor;
                    case WeightTypes.Ton:
                        return _value * WeightFactors.TonToOunceFactor;
                    case WeightTypes.Gram:
                        return _value * WeightFactors.GramToOunceFactor;
                    case WeightTypes.Kilogram:
                        return _value * WeightFactors.KilogramToOunceFactor;
                    case WeightTypes.MetricTon:
                        return _value * WeightFactors.MetricTonToOunceFactor;
                    default:
                        throw new Exception("The Weight Type is not properly set");
                }
            }
        }

        public double AsPounds
        {
            get
                {
                switch (_weightType)
                {
                    case WeightTypes.Ounce:
                        return _value * WeightFactors.OunceToPoundFactor;
                    case WeightTypes.Pound:
                        return _value;
                    case WeightTypes.Ton:
                        return _value * WeightFactors.TonToPoundFactor;
                    case WeightTypes.Gram:
                        return _value * WeightFactors.GramToPoundFactor;
                    case WeightTypes.Kilogram:
                        return _value * WeightFactors.KilogramToPoundFactor;
                    case WeightTypes.MetricTon:
                        return _value * WeightFactors.MetricTonToPoundFactor;
                    default:
                        throw new Exception("The Weight Type is not properly set");
                }

            }

        }

        public double AsTons
        {
            get
            {
                switch (_weightType)
                {
                    case WeightTypes.Ounce:
                        return _value * WeightFactors.OunceToTonFactor;
                    case WeightTypes.Pound:
                        return _value * WeightFactors.PoundToTonFactor;
                    case WeightTypes.Ton:
                        return _value;
                    case WeightTypes.Gram:
                        return _value * WeightFactors.GramToTonFactor;
                    case WeightTypes.Kilogram:
                        return _value * WeightFactors.KilogramToTonFactor;
                    case WeightTypes.MetricTon:
                        return _value * WeightFactors.MetricTonToTonFactor;
                    default:
                        throw new Exception("The Weight Type is not properly set");
                }
            }
        }

        public double AsGrams
        {
            get
            {
                switch (_weightType)
                {
                    case WeightTypes.Ounce:
                        return _value * WeightFactors.OunceToGramFactor;
                    case WeightTypes.Pound:
                        return _value * WeightFactors.PoundToGramFactor;
                    case WeightTypes.Ton:
                        return _value * WeightFactors.TonToGramFactor;
                    case WeightTypes.Gram:
                        return _value;
                    case WeightTypes.Kilogram:
                        return _value * WeightFactors.KilogramToGramFactor;
                    case WeightTypes.MetricTon:
                        return _value * WeightFactors.MetricTonToGramFactor;
                    default:
                        throw new Exception("The Weight Type is not properly set");
                }
            }
        }

        public double AsKilograms
        {
            get
            {
                switch (_weightType)
                {
                    case WeightTypes.Ounce:
                        return _value * WeightFactors.OunceToKilogramFactor;
                    case WeightTypes.Pound:
                        return _value * WeightFactors.PoundToKilogramFactor;
                    case WeightTypes.Ton:
                        return _value * WeightFactors.TonToKilogramFactor;
                    case WeightTypes.Gram:
                        return _value * WeightFactors.GramToKilogramFactor;
                    case WeightTypes.Kilogram:
                        return _value;
                    case WeightTypes.MetricTon:
                        return _value * WeightFactors.MetricTonToKilogramFactor;
                    default:
                        throw new Exception("The Weight Type is not properly set");
                }
            }
        }

        public double AsMetricTon
        {
            get
            {
                switch (_weightType)
                {
                    case WeightTypes.Ounce:
                        return _value * WeightFactors.OunceToMetricTonFactor;
                    case WeightTypes.Pound:
                        return _value * WeightFactors.PoundToMetricTonFactor;
                    case WeightTypes.Ton:
                        return _value * WeightFactors.TonToMetricTonFactor;
                    case WeightTypes.Gram:
                        return _value * WeightFactors.GramToMetricTonFactor;
                    case WeightTypes.Kilogram:
                        return _value * WeightFactors.KilogramToMetricTonFactor;
                    case WeightTypes.MetricTon:
                        return _value;
                    default:
                        throw new Exception("The Weight Type is not properly set");
                }
            }
        }

        public double ConvertWeight(WeightTypes NewWeightType)
        {

            //time to find out if which weightType we are going to
            switch (NewWeightType)
            {
                case WeightTypes.Ounce:
                    return AsOunces;
                case WeightTypes.Pound:
                    return AsPounds;
                case WeightTypes.Ton:
                    return AsTons;
                case WeightTypes.Gram:
                    return AsGrams;
                case WeightTypes.Kilogram:
                    return AsKilograms;
                case WeightTypes.MetricTon:
                    return AsMetricTon;
                default:
                    throw new ArgumentException("Invalid WeightType", "NewWeightType");
            }
        }

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
