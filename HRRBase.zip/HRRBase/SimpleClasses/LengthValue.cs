﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    class LengthValue : INotifyPropertyChanged
    {
        private double _value;
        private LengthTypes _lengthType;

        public event PropertyChangedEventHandler PropertyChanged;

        public LengthValue(double Value, LengthTypes LengthType)
        {
            _value = Value;
            _lengthType = LengthType;
        }

        public void SetLength(double Value, LengthTypes LengthType)
        {
            _value = Value;
            _lengthType = LengthType;
            OnPropertyChanged("AsInches");
            OnPropertyChanged("AsFeet");
            OnPropertyChanged("AsYards");
            OnPropertyChanged("AsMiles");
            OnPropertyChanged("AsMillimeter");
            OnPropertyChanged("AsCentimeter");
            OnPropertyChanged("AsMeter");
            OnPropertyChanged("AsKiloMeter");
        }

        public double AsInches
        {
            get
            {

                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToInchFactor;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToInchFactor;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToInchFactor;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToInchFactor;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToInchFactor;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToInchFactor;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToInchFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsFeet
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToFootFactor;
                    case LengthTypes.Foot:
                        return _value ;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToFootFactor;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToFootFactor;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToInchFactor;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToFootFactor;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToFootFactor;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToFootFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsYards
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToYardFactor;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToYardFactor;
                    case LengthTypes.Yard:
                        return _value;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToYardFactor;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToYardFactor;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToYardFactor;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToYardFactor;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToYardFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsMiles
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToMileFactor;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToMileFactor;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToMileFactor;
                    case LengthTypes.Mile:
                        return _value;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToMileFactor;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToMileFactor;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToMileFactor;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToMileFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsMillimeter
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToMillimeterFactor;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToMillimeterFactor;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToMillimeterFactor;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToMillimeterFactor;
                    case LengthTypes.Millimeter:
                        return _value ;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToMillimeterFactor;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToMillimeterFactor;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToMillimeterFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsCentimeter
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToCentimeterFactor;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToCentimeterFactor;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToCentimeterFactor;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToCentimeterFactor;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToCentimeterFactor;
                    case LengthTypes.Centimeter:
                        return _value ;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToCentimeterFactor;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToCentimeterFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsMeter
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToMeterFactor;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToMeterFactor;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToMeterFactor;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToMeterFactor;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToMeterFactor;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToMeterFactor;
                    case LengthTypes.Meter:
                        return _value;
                    case LengthTypes.Kilometer:
                        return _value * LengthFactors.KilometerToMeterFactor;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double AsKilometer
        {
            get
            {
                switch (_lengthType)
                {
                    case LengthTypes.Inch:
                        return _value * LengthFactors.InchToKilometerFactor;
                    case LengthTypes.Foot:
                        return _value * LengthFactors.FootToKilometerFactor;
                    case LengthTypes.Yard:
                        return _value * LengthFactors.YardToKilometerFactor;
                    case LengthTypes.Mile:
                        return _value * LengthFactors.MileToKilometerFactor;
                    case LengthTypes.Millimeter:
                        return _value * LengthFactors.MillimeterToKilometerFactor;
                    case LengthTypes.Centimeter:
                        return _value * LengthFactors.CentimeterToKilometerFactor;
                    case LengthTypes.Meter:
                        return _value * LengthFactors.MeterToKilometerFactor;
                    case LengthTypes.Kilometer:
                        return _value;
                    default:
                        throw new Exception("The Length Type is not properly set");
                }
            }
        }

        public double ConvertLength(LengthTypes NewLengthType)
        {
            switch (NewLengthType)
            {
                case LengthTypes.Inch:
                    return AsInches;
                case LengthTypes.Foot:
                    return AsFeet;
                case LengthTypes.Yard:
                    return AsYards;
                case LengthTypes.Mile:
                    return AsMiles;
                case LengthTypes.Millimeter:
                    return AsMillimeter;
                case LengthTypes.Centimeter:
                    return AsCentimeter;
                case LengthTypes.Meter:
                    return AsMeter;
                case LengthTypes.Kilometer:
                    return AsKilometer;
                default:
                    throw new ArgumentException("Invalid LengthType", "NewLengthType");
            }
        }
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
