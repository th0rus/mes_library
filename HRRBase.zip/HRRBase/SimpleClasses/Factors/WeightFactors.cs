﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    internal static class WeightFactors
    {
        //Ounce Factors
        public const double OunceToPoundFactor = .0625;
        public const double OunceToTonFactor = .00003125;
        public const double OunceToGramFactor = 28.350;
        public const double OunceToKilogramFactor = .028350;
        public const double OunceToMetricTonFactor = .000028350;

        //Pound Factors
        public const double PoundToOunceFactor = 16;
        public const double PoundToTonFactor = .0005;
        public const double PoundToGramFactor = 453.59;
        public const double PoundToKilogramFactor = .45359;
        public const double PoundToMetricTonFactor = .00045359;

        //Ton Factors
        public const double TonToOunceFactor = 32000;
        public const double TonToPoundFactor = 2000;
        public const double TonToGramFactor = 907180;
        public const double TonToKilogramFactor = 907.18;
        public const double TonToMetricTonFactor = .90718;

        //Gram Factors
        public const double GramToOunceFactor = .035274;
        public const double GramToPoundFactor = .0022046;
        public const double GramToTonFactor = .000011023;
        public const double GramToKilogramFactor = .001;
        public const double GramToMetricTonFactor = .000001;

        //Kilogram Factors
        public const double KilogramToOunceFactor = 35.274;
        public const double KilogramToPoundFactor = 2.2046;
        public const double KilogramToTonFactor = .0011023;
        public const double KilogramToGramFactor = 1000;
        public const double KilogramToMetricTonFactor = .001;

        //MetricTon Factors
        public const double MetricTonToOunceFactor = 35274;
        public const double MetricTonToPoundFactor = 2204.6;
        public const double MetricTonToTonFactor = 1.1023;
        public const double MetricTonToGramFactor = 1000000;
        public const double MetricTonToKilogramFactor = 1000;
    }
}
