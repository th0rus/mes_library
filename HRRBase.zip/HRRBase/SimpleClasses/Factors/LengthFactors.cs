﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRRBases
{
    internal static class LengthFactors
    {
        //Inch factors
        public const double InchToFootFactor = .083333;
        public const double InchToYardFactor = .027778;
        public const double InchToMileFactor = .000015783;
        public const double InchToMillimeterFactor = 25.4;
        public const double InchToCentimeterFactor = 2.54;
        public const double InchToMeterFactor = .0254;
        public const double InchToKilometerFactor = .0000254;

        //Foot factors
        public const double FootToInchFactor = 12;
        public const double FootToYardFactor = .33333;
        public const double FootToMileFactor = .00018939;
        public const double FootToMillimeterFactor = 304.8;
        public const double FootToCentimeterFactor = 30.48;
        public const double FootToMeterFactor = .3048;
        public const double FootToKilometerFactor = .0003048;

        //Yard factors
        public const double YardToInchFactor = 36;
        public const double YardToFootFactor = 3;
        public const double YardToMileFactor = .00056818;
        public const double YardToMillimeterFactor = 914.4;
        public const double YardToCentimeterFactor = 91.44;
        public const double YardToMeterFactor = .9144;
        public const double YardToKilometerFactor = .0009144;

        //Mile factors
        public const double MileToInchFactor = 63360;
        public const double MileToFootFactor = 5280;
        public const double MileToYardFactor = 1760;
        public const double MileToMillimeterFactor = 1609300;
        public const double MileToCentimeterFactor = 160930;
        public const double MileToMeterFactor = 1609.3;
        public const double MileToKilometerFactor = 1.6093;

        //Millimeter factors
        public const double MillimeterToInchFactor = .039370;
        public const double MillimeterToFootFactor = .0032808;
        public const double MillimeterToYardFactor = .0010936;
        public const double MillimeterToMileFactor = .00000062137;
        public const double MillimeterToCentimeterFactor = .1;
        public const double MillimeterToMeterFactor = .001;
        public const double MillimeterToKilometerFactor = .000001;

        //Centimeter factors
        public const double CentimeterToInchFactor = .39370;
        public const double CentimeterToFootFactor = .032808;
        public const double CentimeterToYardFactor = .010936;
        public const double CentimeterToMileFactor = .0000062137;
        public const double CentimeterToMillimeterFactor = 10;
        public const double CentimeterToMeterFactor = .01;
        public const double CentimeterToKilometerFactor = .00001;

        //Meter factors
        public const double MeterToInchFactor = 39.370;
        public const double MeterToFootFactor = 3.2808;
        public const double MeterToYardFactor = 1.0936;
        public const double MeterToMileFactor = .00062137;
        public const double MeterToMillimeterFactor = 1000;
        public const double MeterToCentimeterFactor = 100;
        public const double MeterToKilometerFactor = .001;

        //Kilometer factors
        public const double KilometerToInchFactor = 39370;
        public const double KilometerToFootFactor = 3280.8;
        public const double KilometerToYardFactor = 1093.6;
        public const double KilometerToMileFactor = .62137;
        public const double KilometerToMillimeterFactor = 1000000;
        public const double KilometerToCentimeterFactor = 100000;
        public const double KilometerToMeterFactor = 1000;
    }
}
